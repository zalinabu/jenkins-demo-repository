$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/main/resources/features/login.feature");
formatter.feature({
  "name": "Login",
  "description": "",
  "keyword": "Feature"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I navigate to Interview Prep",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginSteps.iNavigateToInterviewPrep()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see the login page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iShouldSeeTheLoginPage()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Log in as test user",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@test1"
    }
  ]
});
formatter.step({
  "name": "I enter \"test@yahoo.com\" in the Email input box",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iEnterInTheEmailInputBox(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter \"testuser123\" in the Password input box",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iEnterInThePasswordInputBox(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click \"Login\" button",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iClickButton(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I validate I am on \"Interview Prep home\" page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iValidateIAmOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I am creating a new step",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I navigate to Interview Prep",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginSteps.iNavigateToInterviewPrep()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see the login page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iShouldSeeTheLoginPage()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Log in as admin user",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@test2"
    }
  ]
});
formatter.step({
  "name": "I enter \"admin@yahoo.com\" in the Email input box",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iEnterInTheEmailInputBox(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter \"adminuser123\" in the Password input box",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iEnterInThePasswordInputBox(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click \"Login\" button",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iClickButton(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I validate I am on \"Interview Prep home\" page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iValidateIAmOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I am creating a new stepgfdgdg",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I navigate to Interview Prep",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginSteps.iNavigateToInterviewPrep()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see the login page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iShouldSeeTheLoginPage()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Login with invalid credentials - invalid email",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@test3"
    },
    {
      "name": "@test1"
    },
    {
      "name": "@regression"
    },
    {
      "name": "@shakeout"
    },
    {
      "name": "@miniregression"
    }
  ]
});
formatter.step({
  "name": "I enter \"test@gmail.com\" in the Email input box",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iEnterInTheEmailInputBox(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter \"test123\" in the Password input box",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iEnterInThePasswordInputBox(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click \"Login\" button",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iClickButton(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see a \"Incorrect username/password\" error message",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iShouldSeeAErrorMessage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I validate I am on \"login\" page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iValidateIAmOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I navigate to Interview Prep",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginSteps.iNavigateToInterviewPrep()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see the login page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iShouldSeeTheLoginPage()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Login with invalid credentials - invalid password",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@test4"
    }
  ]
});
formatter.step({
  "name": "I enter \"test@yahoo.com\" in the Email input box",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iEnterInTheEmailInputBox(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter \"testinvalid\" in the Password input box",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iEnterInThePasswordInputBox(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click \"Login\" button",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iClickButton(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see a \"Incorrect username/password\" error message",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iShouldSeeAErrorMessage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I validate I am on \"login\" page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iValidateIAmOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I navigate to Interview Prep",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginSteps.iNavigateToInterviewPrep()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see the login page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iShouldSeeTheLoginPage()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Login with invalid credentials - empty fields",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@test5"
    }
  ]
});
formatter.step({
  "name": "I click \"Login\" button",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iClickButton(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see a \"Incorrect username/password\" error message",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iShouldSeeAErrorMessage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I validate I am on \"login\" page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iValidateIAmOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I validate I am on \"login\" page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iValidateIAmOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I navigate to Interview Prep",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginSteps.iNavigateToInterviewPrep()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see the login page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iShouldSeeTheLoginPage()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "calc",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@testcalc"
    }
  ]
});
formatter.step({
  "name": "I \"\" numbers \"\" \"\"",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginSteps.iNumbers(String,String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I \"\" numbers \"\" \"\"",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginSteps.iNumbers(String,String,String)"
});
formatter.result({
  "status": "passed"
});
});